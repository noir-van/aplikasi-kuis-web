# MATH-QUIZ

Aplikasi kuis matematika berbasis web menggunakan HTML, CSS, dan JS.

## Fitur Utama

### Fitur Umum
- Mode Gelap/Terang
- Antarmuka Responsif
- Sistem Autentikasi
- Penyimpanan Data Lokal


### Admin Panel
- Manajemen Siswa
  - Tambah siswa baru
  - Modifikasi data siswa
  - Lihat daftar siswa

- Manajemen Soal
  - Tambah soal baru
  - Edit soal
  - Pengaturan durasi kuis (1-120 menit)

- Nilai Siswa
  - Lihat nilai seluruh siswa
  - Data nilai tersimpan dengan timestamp

- Pengaturan Admin
  - Ubah kata sandi
  - Keamanan akun

### Panel Siswa
- Kuis Matematika
  - Timer otomatis
  - Input jawaban real-time
  - Validasi jawaban langsung

- Riwayat Nilai
  - Lihat nilai pribadi
  - Riwayat lengkap dengan tanggal


## Teknologi

- HTML5
- CSS3 (Flexbox & Grid)
- JavaScript (Vanilla)
- Font Awesome Icons
- LocalStorage

## Instalasi

1. Clone repository ini
2. Buka file `index.html` di browser
3. Login sebagai admin dengan kredensial default:
   - Username: admin
   - Password: admin123

## Penggunaan

### Admin
1. Login sebagai admin
2. Kelola siswa, soal, dan pengaturan melalui panel admin
3. Pantau nilai siswa
4. Atur durasi kuis

### Siswa
1. Login dengan akun yang diberikan admin
2. Mulai kuis dari dashboard
3. Jawab soal dalam batas waktu
4. Lihat nilai di riwayat

## Keamanan

- Autentikasi untuk admin dan siswa
- Penyimpanan password yang aman
- Validasi input
- Proteksi rute

## Pengembang

© 2025 MATH-QUIZ. All rights reserved. 