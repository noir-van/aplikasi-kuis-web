document.addEventListener('DOMContentLoaded', function() {
    
    if (document.getElementById('adminDashboardSection')) {
      const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
      if (!currentUser || currentUser.role !== 'admin') return;
      
      
      const studentsTable = document.getElementById('studentsTable');
      const questionsTable = document.getElementById('questionsTable');
      const addStudentBtn = document.getElementById('addStudentBtn');
      const addQuestionBtn = document.getElementById('addQuestionBtn');
      const addStudentModal = document.getElementById('addStudentModal');
      const closeModalButtons = document.querySelectorAll('.close-modal, .cancel-btn');
      
     
      loadStudents();
      loadQuestions();
      updateStats();
      
      addStudentBtn.addEventListener('click', function() {
        addStudentModal.classList.remove('hidden');
      });
      
      
      addQuestionBtn.addEventListener('click', function() {
        
        alert('Add question functionality would go here');
      });
      
      
      closeModalButtons.forEach(button => {
        button.addEventListener('click', function() {
          addStudentModal.classList.add('hidden');
        });
      });
      
     
      const addStudentForm = document.getElementById('addStudentForm');
      if (addStudentForm) {
        addStudentForm.addEventListener('submit', function(e) {
          e.preventDefault();
          
          const username = document.getElementById('newUsername').value;
          const password = document.getElementById('newPassword').value;
          const fullName = document.getElementById('newFullName').value;
          
         
          if (!username || !password || !fullName) {
            alert('Please fill in all fields');
            return;
          }
          
        
          if (users.some(u => u.username === username)) {
            alert('Username already exists');
            return;
          }
          
         
          const newStudent = {
            id: users.length + 1,
            username: username,
            password: password,
            role: 'student',
            fullName: fullName,
            createdAt: new Date().toISOString()
          };
          
          users.push(newStudent);
          
          
          addStudentModal.classList.add('hidden');
          loadStudents();
          updateStats();
          
          
          addStudentForm.reset();
        });
      }
      
      
      function loadStudents() {
        const tbody = studentsTable.querySelector('tbody');
        tbody.innerHTML = '';
        
        users.filter(u => u.role === 'student').forEach(user => {
          const studentScores = scores.filter(s => s.studentId === user.id);
          const quizzesTaken = studentScores.length;
          const avgScore = quizzesTaken > 0 
            ? Math.round(studentScores.reduce((sum, score) => sum + (score.score / score.total * 100), 0) / quizzesTaken)
            : 0;
          
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${user.username}</td>
            <td>${user.fullName}</td>
            <td>${new Date(user.createdAt).toLocaleDateString()}</td>
            <td>${quizzesTaken}</td>
            <td>${avgScore}%</td>
            <td>
              <button class="secondary-btn edit-btn" data-id="${user.id}">Edit</button>
              <button class="secondary-btn delete-btn" data-id="${user.id}">Delete</button>
            </td>
          `;
          
          tbody.appendChild(row);
        });
        
        
        document.querySelectorAll('.edit-btn').forEach(button => {
          button.addEventListener('click', function() {
            const userId = parseInt(this.getAttribute('data-id'));
            editStudent(userId);
          });
        });
        
        document.querySelectorAll('.delete-btn').forEach(button => {
          button.addEventListener('click', function() {
            const userId = parseInt(this.getAttribute('data-id'));
            deleteStudent(userId);
          });
        });
      }
      
      
      function loadQuestions() {
        const tbody = questionsTable.querySelector('tbody');
        tbody.innerHTML = '';
        
        questions.forEach(question => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${question.text}</td>
            <td>${question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}</td>
            <td>${question.type === 'multiple-choice' ? 'Multiple Choice' : 'True/False'}</td>
            <td>
              <button class="secondary-btn edit-question-btn" data-id="${question.id}">Edit</button>
              <button class="secondary-btn delete-question-btn" data-id="${question.id}">Delete</button>
            </td>
          `;
          
          tbody.appendChild(row);
        });
        
        
        document.querySelectorAll('.edit-question-btn').forEach(button => {
          button.addEventListener('click', function() {
            const questionId = parseInt(this.getAttribute('data-id'));
            editQuestion(questionId);
          });
        });
        
        document.querySelectorAll('.delete-question-btn').forEach(button => {
          button.addEventListener('click', function() {
            const questionId = parseInt(this.getAttribute('data-id'));
            deleteQuestion(questionId);
          });
        });
      }
      
      
      function updateStats() {
        document.getElementById('totalStudents').textContent = users.filter(u => u.role === 'student').length;
        document.getElementById('totalQuizzes').textContent = scores.length;
        
        const avgScore = scores.length > 0 
          ? Math.round(scores.reduce((sum, score) => sum + (score.score / score.total * 100), 0) / scores.length)
          : 0;
        document.getElementById('globalAverage').textContent = `${avgScore}%`;
      }
      
      
      function editStudent(userId) {
        const user = users.find(u => u.id === userId);
        if (!user) return;
        
        
        alert(`Edit student ${user.username} functionality would go here`);
      }
      
      
      function deleteStudent(userId) {
        if (confirm('Are you sure you want to delete this student?')) {
          const index = users.findIndex(u => u.id === userId);
          if (index !== -1) {
            users.splice(index, 1);
            loadStudents();
            updateStats();
          }
        }
      }
      
      
      function editQuestion(questionId) {
        const question = questions.find(q => q.id === questionId);
        if (!question) return;
        
        alert(`Edit question "${question.text}" functionality would go here`);
      }
      
      
      function deleteQuestion(questionId) {
        if (confirm('Are you sure you want to delete this question?')) {
          const index = questions.findIndex(q => q.id === questionId);
          if (index !== -1) {
            questions.splice(index, 1);
            loadQuestions();
          }
        }
      }
      
     
      const navButtons = document.querySelectorAll('.sidebar-btn');
      navButtons.forEach(button => {
        button.addEventListener('click', function() {
         
          navButtons.forEach(btn => btn.classList.remove('active'));
          
        this.classList.add('active');
          
          
          document.querySelectorAll('section').forEach(section => {
            section.classList.add('hidden');
          });
          
          
          const sectionId = this.id.replace('Btn', 'Section');
          document.getElementById(sectionId).classList.remove('hidden');
        });
      });
    }
  });