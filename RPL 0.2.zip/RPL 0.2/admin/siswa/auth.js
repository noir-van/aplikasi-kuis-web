
const users = [
    {
      id: 1,
      username: 'admin',
      password: 'administrator123',
      role: 'admin',
      fullName: 'Administrator',
      createdAt: new Date().toISOString()
    },
    {
      id: 2,
      username: 'student1',
      password: 'student123',
      role: 'student',
      fullName: 'Student One',
      createdAt: new Date().toISOString()
    },
    {
      id: 3,
      username: 'student2',
      password: 'student123',
      role: 'student',
      fullName: 'Student Two',
      createdAt: new Date().toISOString()
    },
    {
      id: 4,
      username: 'student3',
      password: 'student123',
      role: 'student',
      fullName: 'Student Three',
      createdAt: new Date().toISOString()
    },
    {
      id: 5,
      username: 'student4',
      password: 'student123',
      role: 'student',
      fullName: 'Student Four',
      createdAt: new Date().toISOString()
    },
    {
      id: 6,
      username: 'student5',
      password: 'student123',
      role: 'student',
      fullName: 'Student Five',
      createdAt: new Date().toISOString()
    }
  ];
  
  
  const questions = [
    {
      id: 1,
      text: "What is 2 + 2?",
      difficulty: "easy",
      type: "multiple-choice",
      options: ["3", "4", "5", "6"],
      correctAnswer: "4"
    },
    {
      id: 2,
      text: "What is 10 × 5?",
      difficulty: "easy",
      type: "multiple-choice",
      options: ["25", "50", "75", "100"],
      correctAnswer: "50"
    },
    {
      id: 3,
      text: "Solve for x: 2x + 5 = 15",
      difficulty: "medium",
      type: "multiple-choice",
      options: ["5", "10", "7.5", "2.5"],
      correctAnswer: "5"
    },
    {
      id: 4,
      text: "What is 15% of 200?",
      difficulty: "medium",
      type: "multiple-choice",
      options: ["15", "30", "45", "60"],
      correctAnswer: "30"
    },
    {
      id: 5,
      text: "What is the square root of 144?",
      difficulty: "hard",
      type: "multiple-choice",
      options: ["10", "11", "12", "13"],
      correctAnswer: "12"
    }
  ];
  
  
  const scores = [
    {
      id: 1,
      studentId: 2,
      score: 8,
      total: 10,
      difficulty: "easy",
      date: "2023-05-10T10:30:00Z"
    },
    {
      id: 2,
      studentId: 3,
      score: 6,
      total: 10,
      difficulty: "medium",
      date: "2023-05-11T11:45:00Z"
    }
  ];
  
  
  document.addEventListener('DOMContentLoaded', function() {
   
    if (document.getElementById('loginForm')) {
      const loginForm = document.getElementById('loginForm');
      
      loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        
        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
         
          sessionStorage.setItem('currentUser', JSON.stringify(user));
          
         
          if (user.role === 'admin') {
            window.location.href = 'admin.html';
          } else {
            window.location.href = 'student.html';
          }
        } else {
          document.getElementById('errorMsg').textContent = 'Invalid username or password';
          document.getElementById('errorMsg').classList.remove('hidden');
        }
      });
    }
    
    
    const logoutButtons = document.querySelectorAll('#logoutBtn, #adminLogoutBtn');
    logoutButtons.forEach(button => {
      if (button) {
        button.addEventListener('click', function() {
          sessionStorage.removeItem('currentUser');
          window.location.href = 'index.html';
        });
      }
    });
    
    
    if (!document.getElementById('loginForm')) {
      const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
      
      if (!currentUser) {
        window.location.href = 'index.html';
      } else {
        
        const usernameDisplays = document.querySelectorAll('#usernameDisplay, #studentName, #accountUsername');
        usernameDisplays.forEach(display => {
          if (display) {
            display.textContent = currentUser.username;
          }
        });
        
        
        const fullNameDisplays = document.querySelectorAll('#accountFullName');
        fullNameDisplays.forEach(display => {
          if (display && currentUser.fullName) {
            display.textContent = currentUser.fullName;
          }
        });
      }
    }
  });