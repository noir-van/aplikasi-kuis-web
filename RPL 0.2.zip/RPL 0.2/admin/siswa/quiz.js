document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('quizSection')) {
      const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
      if (!currentUser || currentUser.role !== 'student') return;
      
     
      let currentQuestion = 0;
      let score = 0;
      let questions = [];
      let quizQuestions = [];
      let timer;
      let timeLeft = 30;
      
      
      const quizContainer = document.getElementById('quizContainer');
      const difficultySelect = document.getElementById('difficultySelect');
      const questionText = document.getElementById('questionText');
      const answerButtons = document.getElementById('answerButtons');
      const currentQuestionEl = document.getElementById('currentQuestion');
      const quizScoreEl = document.getElementById('quizScore');
      const progressFill = document.getElementById('progressFill');
      const quizResult = document.getElementById('quizResult');
      const finalScoreEl = document.getElementById('finalScore');
      const maxScoreEl = document.getElementById('maxScore');
      const timeLeftEl = document.getElementById('timeLeft');
      
      
      questions = [
        
        ...getQuestionsByDifficulty('easy'),
        
        ...getQuestionsByDifficulty('medium'),
        
        ...getQuestionsByDifficulty('hard')
      ];
      
      
      const difficultyButtons = document.querySelectorAll('[data-difficulty]');
      difficultyButtons.forEach(button => {
        button.addEventListener('click', function() {
          const difficulty = this.getAttribute('data-difficulty');
          startQuiz(difficulty);
        });
      });
      
      
      function startQuiz(difficulty) {
        
        quizQuestions = getQuestionsByDifficulty(difficulty);
        10
        quizQuestions = shuffleArray(quizQuestions).slice(0, 10);
        
        currentQuestion = 0;
        score = 0;
        
        
        difficultySelect.classList.add('hidden');
        quizContainer.classList.remove('hidden');
        quizResult.classList.add('hidden');
        
        
        showQuestion();
      }
      
      
      function showQuestion() {
        if (currentQuestion >= quizQuestions.length) {
          endQuiz();
          return;
        }
        
        const question = quizQuestions[currentQuestion];
        
        
        currentQuestionEl.textContent = currentQuestion + 1;
        progressFill.style.width = `${((currentQuestion + 1) / quizQuestions.length) * 100}%`;
        
       
        questionText.textContent = question.text;
        
        
        answerButtons.innerHTML = '';
        
        
        if (question.type === 'multiple-choice') {
          question.options.forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.addEventListener('click', function() {
              checkAnswer(option);
            });
            answerButtons.appendChild(button);
          });
        } else if (question.type === 'true-false') {
          ['True', 'False'].forEach(option => {
            const button = document.createElement('button');
            button.textContent = option;
            button.addEventListener('click', function() {
              checkAnswer(option);
            });
            answerButtons.appendChild(button);
          });
        }
        
        
        startTimer();
      }
      
      
      function checkAnswer(selectedAnswer) {
        clearInterval(timer);
        
        const question = quizQuestions[currentQuestion];
        const isCorrect = selectedAnswer === question.correctAnswer;
        
        if (isCorrect) {
          score++;
          quizScoreEl.textContent = score;
        }
        
        
        currentQuestion++;
        setTimeout(showQuestion, 1000);
      }
      
     
      function startTimer() {
        timeLeft = 30;
        timeLeftEl.textContent = timeLeft;
        
        timer = setInterval(function() {
          timeLeft--;
          timeLeftEl.textContent = timeLeft;
          
          if (timeLeft <= 0) {
            clearInterval(timer);
          
            currentQuestion++;
            setTimeout(showQuestion, 1000);
          }
        }, 1000);
      }
      
     
      function endQuiz() {
        clearInterval(timer);
        
       
        finalScoreEl.textContent = score;
        maxScoreEl.textContent = quizQuestions.length;
        
       
        quizContainer.classList.add('hidden');
        quizResult.classList.remove('hidden');
        
        
        saveScore(score, quizQuestions.length, quizQuestions[0].difficulty);
      }
      
      
      function getQuestionsByDifficulty(difficulty) {
        return questions.filter(q => q.difficulty === difficulty);
      }
      
     
      function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
      }
      
      
      function saveScore(score, total, difficulty) {
        const currentUser = JSON.parse(sessionStorage.getItem('currentUser'));
        
        
        console.log(`Score saved: ${score}/${total} for ${currentUser.username} (${difficulty})`);
        
        
        scores.push({
          id: scores.length + 1,
          studentId: currentUser.id,
          score: score,
          total: total,
          difficulty: difficulty,
          date: new Date().toISOString()
        });
      }
      
      
      const navButtons = document.querySelectorAll('.sidebar-btn');
      navButtons.forEach(button => {
        button.addEventListener('click', function() {
          
          navButtons.forEach(btn => btn.classList.remove('active'));
          
          this.classList.add('active');
          
          
          document.querySelectorAll('section').forEach(section => {
            section.classList.add('hidden');
          });
          
         
          const sectionId = this.id.replace('Btn', 'Section');
          document.getElementById(sectionId).classList.remove('hidden');
        });
      });
    }
  });