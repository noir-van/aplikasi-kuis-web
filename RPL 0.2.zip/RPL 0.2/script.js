document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    
   
    const users = {
        'admin': {
            password: 'admin123',
            role: 'admin'
        },
        'student': {
            password: 'student123',
            role: 'student'
        }
    };

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        if (users[username] && users[username].password === password) {
           
            localStorage.setItem('currentUser', JSON.stringify({
                username: username,
                role: users[username].role
            }));
            
            
            if (users[username].role === 'admin') {
                window.location.href = 'admin.html';
            } else {
                window.location.href = 'student.html';
            }
        } else {
            alert('Username atau password salah!');
        }
    });
}); 